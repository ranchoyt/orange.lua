alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"
E 
E 
E 
S 1
su -c iptables --flush
iptables --flush
su -c iptables --flush
iptables --flush
iptables -F
iptables -F
iptables --flush
iptables --flush
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -F
iptables -t nat -F
iptables -t mangle -F
iptables -X
iptables --flush
iptables -F
iptables --flush
iptables -F
iptables -X
am force-stop com.pubg.krmobile
R /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
R /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config/Android/Updater.ini
R /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/ZEN.pak
R /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.6.0.15532.pak
R /data/data/com.pubg.krmobile/lib/*
R /data/data/com.pubg.krmobile/databases
pm install -r /data/app/com.pubg.krmobile*/base.apk
su -c iptables -F
su -c iptables -X
su -c iptables --flush
iptables -F
iptables -X
iptables --flush
SP 755 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
SP 755 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/*
R /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
S 0.1
E -ne '                   \033[1;32m  Process Done✓ \r'
S 0.1
E -ne ' \n'
E "                   \033[0m"