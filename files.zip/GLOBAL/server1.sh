ip6tables=/system/bin/ip6tables
iptables=/system/bin/iptables
uptime
#====================================
alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"
PKG=com.tencent.ig
su -c iptables -F
su -c iptables -X
su -c iptables --flush
iptables -F
iptables -X
iptables --flush
awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list > /data/media/0/ZENITSU
ZENITSU=$(cat /data/media/0/ZENITSU)
su -c iptables -I INPUT -m owner --uid-owner $ZEN -p tcp -j DROP &>/dev/null
su -c iptables -I OUTPUT -m owner --uid-owner $ZEN -p tcp -j DROP &>/dev/null
su -c ip6tables -I INPUT -m owner --uid-owner $ZEN -p tcp -j DROP &>/dev/null
su -c ip6tables -I OUTPUT -m owner --uid-owner $ZEN -p tcp -j DROP &>/dev/null
iptables -I INPUT -m owner --uid-owner $ZEN -p tcp -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $ZEN -p tcp -j DROP &>/dev/null
ip6tables -I INPUT -m owner --uid-owner $ZEN -p tcp -j DROP &>/dev/null
ip6tables -I OUTPUT -m owner --uid-owner $ZEN -p tcp -j DROP &>/dev/null
rm -rf {device_idB,device_idD,device_idF,id,idd,name};
touch /data/media/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
lib=`ls -mR $(DUMP com.tencent.ig legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v sosna`

ZENITSU(){
cp $lib/$1 $lib/$1.bak
}
NEZUKO(){
mv $lib/$1.bak $lib/$1
}
awk -v min=1111111111111111 -v max=2999999999999999 'BEGIN{srand(); print int(min+rand()*(max-min+1))}' | tr -d '\n' > id
awk -v min=6500000000 -v max=6509999999 'BEGIN{srand(); print int(min+rand()*(max-min+1))}' | tr -d '\n' > idd
cat /dev/urandom | tr -cd 'a-f0-9' | head -c 9 | tr -d '\n' > name
cat /proc/sys/kernel/random/uuid | tr -d '\n' > device_idB
od -x /dev/urandom | head -1 | awk '{OFS=""; print $2$3,$4,$5,$6,$7$8$9}' | tr -d '\n' > device_idD
od -x /dev/urandom | head -1 | awk '{OFS=""; print $2$3,$4,$5,$6,$7$8$9}' | tr -d '\n' > device_idF
SP 777 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
R /data/data/com.tencent.ig/databases
chmod 640 /data/system/packages.list
rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo '[/Script/Client.GDolphinUpdater]\nEnabled=false\nDisable=true' > /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
echo '[/Script/Client.GDolphinAntiCheat]\nEnabled=false\nDisable=true' > /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
####
ZENITSU libtprt.so
ZENITSU libgcloud.so
ZENITSU libUE4.so
SP -R 755 /data/data/com.tencent.ig/lib/*
R /data/data/com.tencent.ig/lib/libBugly.so
R /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{SrcVersion.ini,coverversion.ini}
R /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
echo '[main]
lastregion=ZEN
lastshop=NEZ
lastsplitminipak=ZENITSU
savedregion=TEN
savedshop=NEZUKO
savedsplitminipak=0' > /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/coverversion.ini

cat /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/coverversion.ini > /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData/LightData3036393187.ltz
SP 550 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/{AntiCheat.ini,Updater.ini}
SP 550 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/coverversion.ini
SP 550 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /data/media/0/Android/data/com.tencent.ig/files/TGPA
am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
while [ ! -d /data/media/0/Android/data/com.tencent.ig/files/TGPA ]; do sleep 1; done
R $lib/{libUE4.so,libtprt.so,libgcloud.so}
NEZUKO libtprt.so
NEZUKO libgcloud.so
NEZUKO libUE4.so
SP 755 /data/data/com.tencent.ig/lib/*
SP 550 /data/data/com.tencent.ig/files
R /data/data/com.tencent.ig/files/*
S 0.5
touch /data/data/com.tencent.ig/files/ano_tmp
SP 000 /data/data/com.tencent.ig/files/ano_tmp
SP 550 /data/data/com.tencent.ig/files
R /data/data/com.tencent.ig/app_crashrecord
touch /data/data/com.tencent.ig/app_crashrecord
S 1
R /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config/Android/Updater.ini
R /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
su -c iptables -F
su -c iptables -X
su -c iptables --flush
iptables -F
iptables -X
iptables --flush
rm -rf {device_idB,device_idD,device_idF,id,idd,name};
rm -rf /data/app/com.tencent.ig*/oat
awk -v min=1111111111111111 -v max=2999999999999999 'BEGIN{srand(); print int(min+rand()*(max-min+1))}' | tr -d '\n' > id
awk -v min=6500000000 -v max=6509999999 'BEGIN{srand(); print int(min+rand()*(max-min+1))}' | tr -d '\n' > idd
cat /dev/urandom | tr -cd 'a-f0-9' | head -c 9 | tr -d '\n' > name
cat /proc/sys/kernel/random/uuid | tr -d '\n' > device_idB
od -x /dev/urandom | head -1 | awk '{OFS=""; print $2$3,$4,$5,$6,$7$8$9}' | tr -d '\n' > device_idD
od -x /dev/urandom | head -1 | awk '{OFS=""; print $2$3,$4,$5,$6,$7$8$9}' | tr -d '\n' > device_idF
touch /data/media/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
rm -rf {device_idB,device_idD,device_idF,id,idd,name};
echo "𝙴𝚡𝚎𝚌𝚞𝚝𝚒𝚘𝚗 𝙲𝚘𝚖𝚙𝚕𝚎𝚝𝚎"
